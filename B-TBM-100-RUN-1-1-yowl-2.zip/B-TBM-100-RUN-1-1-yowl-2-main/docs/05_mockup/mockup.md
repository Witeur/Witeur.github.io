# Design Choices and Accessibility Decisions

## 1. Key Design Choices

1. **Color Scheme**
   - High contrast colors (yellow highlights on dark backgrounds) to ensure readability.
   - Colors chosen to differentiate interactive elements like buttons and links.

2. **Typography**
   - Clear, modern fonts: "Orbitron" for headers and "Rajdhani" for content.
   - Larger font sizes for readability on all devices.

3. **Navigation**
   - Fixed header with logo and main links for consistent access.
   - Clear visual hierarchy to guide users from registration/login → home → posts → achievements.

4. **Interactive Elements**
   - Buttons and links visually distinct with hover effects.
   - Achievement boxes clearly indicate locked vs unlocked status using color and opacity.

5. **Minimalist Layout**
   - Focused screens with essential information only.
   - Avoids clutter to reduce cognitive load.

## 2. Accessibility Decisions

1. **Contrast and Visibility**
   - Backgrounds and text maintain sufficient contrast ratios.
   - Locked achievements use grayscale but remain legible.

2. **Keyboard Navigation**
   - All buttons and links are focusable and actionable via keyboard.

3. **Feedback and Status Indicators**
   - Button states (disabled/loading) are visually distinguishable.
   - Achievement unlocks provide visual confirmation, supporting users with different abilities.

---

_This file explains why specific design decisions were made to support both usability and accessibility for the MVP mockups._
