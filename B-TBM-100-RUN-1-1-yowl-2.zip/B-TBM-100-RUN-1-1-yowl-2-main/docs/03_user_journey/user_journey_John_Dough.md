


## User Journey — Quest Network

## User Journey — John Dough (Introverted Gamer)

### User Profile

- **User type:** Teen Gamer  
- **Goal:** Be entertained, scroll endlessly, consume gaming content  
- **Device:** Mobile phone / Desktop computer  
- **Context:** Late evening, after school, long uninterrupted sessions  

---

### 1. Discovery

**Action:**  
John sees a short gaming clip shared by a friend on Discord.

**Thoughts:**  
> “That clip was actually funny… maybe this app has more like it.”

**Pain Point:**  
He assumes most social networks are boring or overly social.

---

### 2. Sign Up

**Action:**  
Downloads the app and signs up quickly using a gaming-related email.

**Thoughts:**  
> “If this takes too long, I’m uninstalling.”

**Pain Point:**  
Too many steps break his focus and patience.

**Opportunity:**  
One-tap signup and instant access to content.

---

### 3. Onboarding

**Action:**  
Selects interests such as *Gaming, Esports, Memes*.

**Thoughts:**  
> “Good, I don’t need to follow people I don’t care about.”

**Pain Point:**  
Too much onboarding kills momentum.

---

### 4. Browse Feed

**Action:**  
Scrolls through short gaming clips, highlights, and memes.

**Thoughts:**  
> “This is actually fun… let’s keep scrolling.”

**Pain Point:**  
Repetitive or non-gaming content would break immersion.

---

### 5. Interact

**Action:**  
Likes a clip, saves another, rarely comments.

**Thoughts:**  
> “I like that I don’t have to talk if I don’t want to.”

**Pain Point:**  
Forced social interaction would push him away.

---

### 6. Create Content

**Action:**  
Eventually reposts a funny gaming clip.

**Thoughts:**  
> “That was easy. Didn’t take much effort.”

**Pain Point:**  
Complex creation tools discourage participation.

---

### 7. Feedback & Engagement

**Action:**  
Receives likes and a few comments.

**Thoughts:**  
> “Nice. People liked that.”

**Pain Point:**  
Too many notifications would feel overwhelming.

---

### 8. Return Loop

**Action:**  
Returns daily to scroll after school.

**Success Metric:**  
Long session duration and repeat use.