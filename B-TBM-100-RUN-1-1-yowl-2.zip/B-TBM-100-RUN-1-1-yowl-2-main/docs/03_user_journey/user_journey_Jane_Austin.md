## User Journey — Quest Network



## User Journey — Jane Austin (Socialite / Cosplayer)

### User Profile

- **User type:** Young Adult / Social Creator  
- **Goal:** Gain followers, showcase cosplays, build reputation  
- **Device:** Mobile phone  
- **Context:** Evenings and weekends, long intentional sessions  

---

### 1. Discovery

**Action:**  
Jane sees a cosplay post reshared on Instagram.

**Thoughts:**  
> “Wow, people here actually care about cosplay.”

**Pain Point:**  
Other platforms mix her content with unrelated topics.

---

### 2. Sign Up

**Action:**  
Signs up using social login.

**Thoughts:**  
> “I hope this platform lets me stand out.”

**Pain Point:**  
A poorly designed UI would hurt her confidence in posting.

---

### 3. Onboarding

**Action:**  
Follows cosplay creators and fashion-related subjects.

**Thoughts:**  
> “This already feels more focused than other apps.”

**Pain Point:**  
If she can’t find her niche quickly, she’ll leave.

---

### 4. Browse Feed

**Action:**  
Explores cosplay, makeup tutorials, and fashion posts.

**Thoughts:**  
> “I could learn a lot from these people.”

**Pain Point:**  
Seeing irrelevant content reduces motivation.

---

### 5. Interact

**Action:**  
Likes, comments, and starts conversations.

**Thoughts:**  
> “People here actually reply.”

**Pain Point:**  
Low engagement would make posting feel pointless.

---

### 6. Create Content

**Action:**  
Uploads a curated cosplay post with captions and tags.

**Thoughts:**  
> “I want this to look perfect, but not take forever.”

**Pain Point:**  
Too many tools slow her down.

---

### 7. Feedback & Engagement

**Action:**  
Receives likes, comments, new followers, DMs.

**Thoughts:**  
> “Yes! This is working.”

**Pain Point:**  
Spam or toxic comments would discourage her.

---

### 8. Return Loop

**Action:**  
Returns multiple times a day to check stats and replies.

**Success Metric:**  
Follower growth and frequent posting.