## User Journey — Quest Network

## User Journey — Jean Claude (Casual Salaryman)

### User Profile

- **User type:** Working Adult  
- **Goal:** Take short mental breaks, learn something new, light social interaction  
- **Device:** Mobile / Desktop  
- **Context:** Work breaks, commute, short sessions  

---

### 1. Discovery

**Action:**  
Sees the app recommended in a group chat.

**Thoughts:**  
> “Maybe this is better than endlessly scrolling news.”

**Pain Point:**  
Doesn’t want another complicated app.

---

### 2. Sign Up

**Action:**  
Registers quickly with email.

**Thoughts:**  
> “Okay, this didn’t waste my time.”

**Pain Point:**  
Long setup would make him quit immediately.

---

### 3. Onboarding

**Action:**  
Skips most onboarding or selects broad interests.

**Thoughts:**  
> “I’ll see what this shows me first.”

**Pain Point:**  
Too much personalization feels like work.

---

### 4. Browse Feed

**Action:**  
Sees short news bites, fun facts, trending posts.

**Thoughts:**  
> “That’s actually interesting.”

**Pain Point:**  
If nothing catches his eye quickly, he leaves.

---

### 5. Interact

**Action:**  
Likes a post or leaves a short comment.

**Thoughts:**  
> “Nice, that was a good discussion.”

**Pain Point:**  
Complex interaction flows slow him down.

---

### 6. Create Content

**Action:**  
Reposts an article or shares a quick thought.

**Thoughts:**  
> “That took 10 seconds. Perfect.”

**Pain Point:**  
Anything longer than that isn’t worth it.

---

### 7. Feedback & Engagement

**Action:**  
Gets a reply or reaction.

**Thoughts:**  
> “That was pleasant.”

**Pain Point:**  
Too many notifications would annoy him.

---

### 8. Return Loop

**Action:**  
Returns during the next break.

**Success Metric:**  
Short but frequent sessions.
