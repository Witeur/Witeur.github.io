# Introduction to the Figma Prototype

## Overview

This Figma prototype presents the **interactive design and user flow** for our application, starting from user entry and progressing through key screens and interactions.

The prototype simulates the main journeys users will take, including registering, logging in, creating content, and viewing progress through achievements. It is designed to help stakeholders, testers, and developers **visualize the experience before development begins**.

The link below opens the prototype in presentation mode, allowing anyone with access to click through the screens as if they were using the real app:

📎 **Prototype URL:**  
https://www.figma.com/proto/rdnwzfJVUmOV5tIMKRKgcC/L-%C3%A9quipe-de-lucas.bouquain-team-library?node-id=0-1&t=O0jBzRVq6mqdkTPZ-1

## Purpose of the Prototype

This prototype serves multiple goals:

- **Demonstrate the intended user experience** — how screens flow from one to another.  
- **Show interaction patterns** such as buttons, transitions, and navigation.  
- **Support usability testing** before implementation.  
- **Communicate design intent to developers and collaborators** without needing code. :contentReference[oaicite:1]{index=1}

## How to Use It

1. Click the prototype link above.  
2. Navigate through the screens by interacting with hotspots and buttons (e.g., “Login”, “Create Post”, “Achievements”).  
3. Use the Figma presentation controls to move between frames or screens (arrows, click areas). :contentReference[oaicite:2]{index=2}

## What’s Included

The prototype covers the core MVP interactions:

- User onboarding (registration & login)  
- Main dashboard or home screen  
- Post creation screen  
- Achievement overview and unlocking flow  

This prototype reflects how the final product **should feel and behave** before actual development.


