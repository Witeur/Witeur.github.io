# interviews.md

## Objective
These interviews are taken with the main purpose being to find a core issue when it comes to social networks and how to solve them through the product we're trying to push.

---

## Interview Details
- **Number of interviews:**  3
- **Target users:** Students
- **Method:** Oral Interview
- **Date:** 01/06/2026 

---

## Interview 1
**Participant:** Philippe Rochefeuille  
**Profile:**  Casual 
**Context:**  To pass the time

### Needs
- To pass the time, to communicate with people, no publishing

### Frustrations
- Ads being everywhere and breaking the feed.

### Habits / Current Behavior
- Scroll/Communication

### Expectations
- Better filter towards people, better content algorithm

### Key Insight for MVP
- Anonymous content

---

## Interview 2
**Participant:** Soraia CATHERINE  
**Profile:**  Hard Scroller
**Context:**  Entertainment/Search for Ideas

### Needs
- Look for something interesting, something passionate

### Frustrations
- Ads, too many ads

### Habits / Current Behavior
- Dancing with video, listen to music, scroll

### Expectations
- Get rid of ads.

### Key Insight for MVP
- Better aimed content.

---

## Interview 3
**Participant:** Enzo BAVIGNE  
**Profile:** Scroller/No Publishing 
**Context:**  To pass the time

### Needs
- Entertainment

### Frustrations
- Too many ads

### Habits / Current Behavior
- No behavior towards social network

### Expectations
- Less predatory data usage

### Key Insight for MVP
- No particular insight.

---

## Synthesis

### Common Needs
- The main need shared by all the candidates is the need to pass the time and entertain themselves.

### Common Frustrations
- The main frustrations lie in the ads and the lack of aimed content towards the users.

### Observed Habits
- Most of them tend to watch more than publish content.

---

## MVP Implications

### Core Problem
- How to generate revenue and keep users on the website without having too many ads or forcing users to create/publish content.

### Must-Have Features
- Content Algorithm aimed at the users, Main feed.

### Out of Scope (for MVP)
- Sharing with friends, Wide interaction.

---

## Summary
These interviews helped us better understand the needs and frustrations of users when it comes to social networks, and what to avoid in the production phase.
