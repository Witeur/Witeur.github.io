# Problem Statement

## Background
Modern social networks are primarily designed around passive content consumption, such as scrolling feeds, liking posts, and reacting to short-form updates. While these platforms are highly engaging, they often lack meaningful progression, purpose, or long-term motivation for users.

## Problem
Online social interaction has become repetitive and shallow. Users have little sense of achievement, challenge, or growth, and participation rarely feels rewarding beyond short-term validation.

## Affected Users
- People who enjoy videogames and structured progression systems  
- Users seeking more meaningful, goal-oriented social interaction  
- Online communities that want stronger engagement and collaboration  

## Impact
The absence of progression and purpose leads to declining user motivation, social fatigue, and reduced long-term engagement. Interactions often feel empty or transactional, making it difficult for communities to sustain interest over time.

## Current Alternatives
Existing social networks focus on metrics such as likes, followers, and views. While some platforms include light gamification, these systems are typically superficial and do not fundamentally change how users interact or collaborate.

## Summary
There is no mainstream social network that treats social interaction as a goal-driven, engaging experience similar to a videogame. Users who value progression, challenges, and achievement lack a platform designed around these principles.
