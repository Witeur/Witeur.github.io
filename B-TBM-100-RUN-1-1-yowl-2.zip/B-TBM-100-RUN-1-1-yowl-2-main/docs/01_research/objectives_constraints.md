# Objectives, Assumptions, Risks, and Constraints

## Objectives
The product aims to:

- Increase user engagement compared to traditional social networks  
- Encourage meaningful interaction through clear goals  
- Improve long-term retention using progression systems  
- Support community building and collaboration  
- Remain fun and easy to use for both gamers and non-gamers  

---

## Assumptions
This project is based on the following assumptions:

- Some users want a social network that feels more like a game
- Gamification is a powerful motivator.
- Users are willing to learn simple progression mechanics.
- Social interaction can be structured without feeling fake.
- The platform can start small and grow over time.

---

## Constraints
The project must operate within these limits:

### Technical Constraints
- Limited development time and resources
- Increased complexity with higher trafic.
- Real-time features add technical difficulty
- Moderation is needed, especially when it comes to publishing content.

### Design Constraints
- Gamification must not feel forced or shallow.
- The platform must be easy to learn but still offer depth.
- Achievements and quests must stay meaningful over time.
- Systems must prevent spam or reward farming.

### Social & Ethical Constraints
- Avoid creating competition or pressure, also known as FOMO (Fear Of Missing Out)
- Prevent users from focusing only on rewards.
- Avoid addictive or manipulative mechanics (Lootboxes, Real Gambling, etc...)
- Make the platform accessible to non-gamers, without changing the core of the platform.

### Legal & Platform Constraints
- Follow privacy and data protection laws
- Enforce content moderation rules
- Design with age-appropriate use in mind
- Follow hosting and app store policies

---

## Risks
Possible risks include:

- Users focusing more on the game than social interaction
- Burnout caused by poorly balanced progression
- Low adoption due to complex onboarding
- Difficulty creating new quests and content over time
- Toxic behavior caused by competition

---

## Summary
Creating a game-like social network involves technical, social, and ethical challenges. The main challenge is balancing progression and fun with healthy social interaction and long-term sustainability.

