# benchmark.md

## Context
This benchmark analyzes a **social network MVP focused on missions, achievements, and meaningful interactions** in comparison with existing platforms. The objective is to understand current market offerings and identify clear differentiation opportunities for the MVP.

---

## Reference MVP Concept

**Concept Overview**  
A social network designed to encourage positive, intentional engagement through structured participation rather than passive consumption.

**Core Mechanics**
- **Missions:** Small challenges or goals that encourage action
- **Achievements:** Earned progress indicators (not vanity metrics)
- **Meaningful interactions:** Quality-focused engagement over quantity

**Target Users**  
Young adults and students seeking purpose-driven and motivating social experiences.

---

## Competitor Comparison

### Instagram
**Primary Focus:** Visual content and personal branding  

**Strengths**
- High user engagement
- Simple content creation and sharing
- Strong network effects

**Limitations**
- Heavy emphasis on likes, followers, and appearance
- Encourages passive scrolling
- Limited sense of progression or purpose

**Difference vs MVP**
- MVP removes or reduces vanity metrics
- MVP rewards intentional participation through missions and achievements

---

### TikTok
**Primary Focus:** Entertainment and viral content discovery  

**Strengths**
- Highly engaging recommendation algorithm
- Fast and addictive content consumption

**Limitations**
- Interactions are often shallow
- Content creation can feel intimidating
- No long-term sense of user progression

**Difference vs MVP**
- MVP prioritizes completion and interaction over virality
- MVP focuses on small, achievable actions rather than performance

---

### BeReal
**Primary Focus:** Authenticity and real-life moments  

**Strengths**
- Low-pressure posting environment
- Encourages authenticity over curation

**Limitations**
- Limited interaction features
- Single daily prompt restricts engagement depth

**Difference vs MVP**
- MVP enables continuous engagement through missions
- MVP introduces structured progression via achievements

---

### Discord
**Primary Focus:** Community-based communication  

**Strengths**
- Strong sense of belonging
- Real-time and group-based interaction

**Limitations**
- Requires active moderation
- Lacks built-in motivation or progression systems

**Difference vs MVP**
- MVP integrates gamification (missions and achievements)
- MVP actively guides interactions instead of leaving them open-ended

---

## Key Differentiating Points
- Purpose-driven interactions instead of passive consumption
- Missions that encourage meaningful and intentional actions
- Achievements based on behavior, not popularity
- Reduced emphasis on likes and follower counts
- Progression systems that motivate long-term engagement

---

## Market Positioning Summary
While most existing social networks optimize for attention, virality, and content volume, this MVP focuses on **intentional engagement, motivation, and personal progress**. It positions itself between traditional social platforms and habit-forming apps by combining community interaction with structured purpose.

