# Retours utilisateurs – Tests de l’application

## Utilisateur 1 – Philippe

> L’inscription et la connexion étaient rapides et simples, ce qui est rassurant.  
> La création d’un post est intuitive et je n’ai pas eu besoin d’aide pour y parvenir.  
> En consultant la page des succès, j’ai aimé le concept, mais je n’ai pas tout de suite compris comment les succès se débloquaient.  
> Après avoir passé un peu plus de temps sur l’application, c’est devenu plus clair et cela m’a donné envie d’interagir davantage.

---

## Utilisateur 2 - Gregory

> Dans l’ensemble, l’application est facile à comprendre et ne donne pas une impression de surcharge.  
> En revanche, je n’étais pas toujours sûr que mes actions avaient bien été prises en compte, notamment pour les succès.  
> Des retours visuels ou de petites notifications après certaines actions rendraient l’expérience plus rassurante.

---

## Utilisateur 3 – Soraya

> J’ai apprécié le parcours global de l’application : inscription, connexion, publication, puis consultation des succès.  
> Tout est bien organisé et logique.  
> Les succès ajoutent un aspect ludique et donnent envie d’explorer davantage.  
> Une courte introduction au début expliquant le but de l’application et le fonctionnement des succès rendrait l’expérience encore plus accueillante.
