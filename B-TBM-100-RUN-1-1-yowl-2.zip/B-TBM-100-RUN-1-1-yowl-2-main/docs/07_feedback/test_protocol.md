# Protocol – User Experience Flow

## 1. Registration
New users must create an account to join the platform.

Users are asked to:
- Choose a username
- Enter an email address
- Create a password

Once registered, users gain access to all core features of the platform.

---

## 2. Login
Registered users log in to access their personal space.

After logging in, users can:
- Create content
- Track their progress
- Unlock achievements

---

## 3. Create a Post
Logged-in users can create posts.

Posts allow users to:
- Share content
- Express ideas
- Interact with the platform

Each post is associated with the user who created it.

---

## 4. Achievements
The platform includes a progression system based on achievements.

### Unlocking Achievements
Users unlock achievements by completing specific actions or missions, such as:
- Creating their first post
- Reaching certain milestones
- Participating actively on the platform

Unlocked achievements are saved automatically.

---

### Viewing Achievements
Users can view all achievements on a dedicated page.

- Unlocked achievements are highlighted
- Locked achievements remain visible but inactive
- This encourages progression and engagement

---

## 5. User Journey Summary
1. User registers
2. User logs in
3. User creates content
4. User completes actions
5. User unlocks and views achievements

---

## 6. Goal of the Platform
The platform aims to:
- Encourage user participation
- Reward engagement
- Provide a clear sense of progression
