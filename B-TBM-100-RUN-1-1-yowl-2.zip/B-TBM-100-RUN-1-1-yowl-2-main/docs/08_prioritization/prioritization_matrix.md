# MVP Scope

## Main User Flow
1. **User Registration & Login**
   - Users create an account or log in to access the platform.
2. **Content Creation**
   - Logged-in users can create and publish posts.
3. **Achievements / Gamification**
   - Users can view achievements.
   - Certain achievements unlock automatically based on user actions (e.g., creating a post).

---

## Essential Screens
1. **Landing / Login Screen**
   - Register or log in.
2. **Home / Feed Screen**
   - View posts and interact minimally with content.
3. **Create Post Screen**
   - Simple form for submitting a post.
4. **Achievements Screen**
   - View unlocked and locked achievements.

---

## Minimal Features
- User account creation and login
- Post creation
- Display of achievements
- Automatic unlocking of achievements tied to user actions
- Basic visual cues for unlocked/locked achievements

---

## Explicitly Excluded
- Notifications system (e.g., alerts for unlocked achievements)
- Advanced post interactions (likes, comments, sharing)
- Full user profiles and settings
- Admin or moderation features
- Social network integration (friends, followers)
- Detailed analytics or statistics

---

**Goal:** The MVP focuses on the core experience: register → log in → create content → track achievements, ensuring quick validation and user feedback.
