# MVP Prioritization Matrix (MoSCoW)

This matrix explains how features were prioritized for the Minimum Viable Product (MVP).
The goal of the MVP is to validate the core concept: allowing users to interact, publish content, and stay engaged through achievements.

---

## Must Have (Essential for MVP)

These features are necessary for the application to function and to test its main value.

| Feature | Justification |
|------|--------------|
| User registration | Users must be able to create an account to access the platform. |
| User login | Authentication is required to identify users and personalize their experience. |
| Create a post | Posting content is the core interaction of the application. |
| View achievements | Achievements support user motivation and engagement. |
| Unlock achievements automatically | This validates the gamification concept of the app. |

---

## Should Have (Important but not critical)

These features improve the experience but are not strictly required to validate the MVP.

| Feature | Justification |
|------|--------------|
| Visual feedback when an achievement is unlocked | Helps users understand that their actions have an impact. |
| Display unlocked achievements separately | Improves clarity and user satisfaction. |
| Basic profile page | Helps users recognize their account and activity. |

---

## Could Have (Nice to have)

These features add comfort or engagement but can be postponed.

| Feature | Justification |
|------|--------------|
| Notifications system | Enhances engagement but is not required for MVP validation. |
| Achievement animations | Improves visual appeal without impacting core functionality. |
| Onboarding or tutorial screens | Useful for new users but optional at early stage. |

---

## Won’t Have (Out of scope for MVP)

These features are intentionally excluded from the MVP to stay focused.

| Feature | Justification |
|------|--------------|
| Private messaging | Not necessary to test the main concept. |
| Advanced customization | Would increase complexity without immediate value. |
| Social interactions (likes, comments) | Can be added later after core usage is validated. |

---

## Summary

The MVP focuses on:
- Simple user access (register & login)
- Content creation
- Gamification through achievements

This prioritization ensures a functional, testable product while leaving room for future improvements.
