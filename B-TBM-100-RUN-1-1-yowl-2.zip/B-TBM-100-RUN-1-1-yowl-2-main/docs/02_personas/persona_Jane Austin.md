# Persona: <Persona Jane Austin>

## Overview
- **Age range:** 23 years old
- **Role / Archetype:**  Socialite
- **Tech familiarity:**  Medium
- **Primary context of use:** Mobile ; Long sessions.

## Goals
- Want to find new people
- Focused on fashion and cosplay

## Motivations
- Wants to post her cosplays and find out more about fashion statements.
- Other main source of socializing, reputation.

## Behaviors
-  Will spend a lot of time posting, curating her posts.
-  Likes attention and conversation.

## Pain Points
-  Other subjects will not interest her.
-  May drop the app if people don't follow her.

## Needs & Expectations
-  Want to have new followers
-  Further cosplay goals.

## Success Criteria
-  To be more famous than yesterday.
-  Developing her skillset.