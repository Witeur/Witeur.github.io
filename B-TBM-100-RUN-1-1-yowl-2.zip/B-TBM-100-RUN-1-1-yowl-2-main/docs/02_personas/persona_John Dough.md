# Persona: <Persona John Dough>

## Overview
- **Age range:** 15 years old
- **Role / Archetype:**  Introverted/Gamer
- **Tech familiarity:**  High
- **Primary context of use:** Mobile/Desktop ; Long sessions

## Goals
- Entertain themselves.
- The act of scrolling.
- Loves video games.

## Motivations
- Enjoys gaming/gaming related hobbies
- Is focused on leisure.

## Behaviors
-  Will focus on a specific aspect for long period of times.
-  Is mostly focused on gaming

## Pain Points
-  Traditional social networks feel boring.
-  Low Attention Span.

## Needs & Expectations
-  Want to be entertained
-  User's freedom.

## Success Criteria
-  Had fun.
-  Dopamine hits.