# Persona: <Persona Jean Claude>

## Overview
- **Age range:** 30 years old
- **Role / Archetype:**  Casual Salaryman
- **Tech familiarity:**  Low - Medium
- **Primary context of use:** Mobile/Desktop ; Short sessions

## Goals
- Catch with the news.
- Find out other hobbies.
- Discuss with new people.

## Motivations
- Enjoys finding out new information and reposting it.
- To entertain themselbes during their breaks.

## Behaviors
-  Will log shortly and if he doesn't find anything, will just sign out.
-  Doesn't have any specific interest, depends on the mood.

## Pain Points
-  Content needs to be aimed at him.
-  Doesn't have a lot of time.

## Needs & Expectations
-  Wants to be entertained.
-  Is curious in learning some facts.

## Success Criteria
-  Was able to take a fun break, decompress.
-  Had a nice conversation.