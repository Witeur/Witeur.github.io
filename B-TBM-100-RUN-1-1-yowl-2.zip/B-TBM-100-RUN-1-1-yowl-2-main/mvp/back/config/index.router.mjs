import express, { Router } from "express";
// import { router as userRouter} from "./connect_user/user.mjs"
import { router as userRouter } from "./src/connect_user/user.mjs"
const router = Router();

router.use("/", userRouter);

export default router;
