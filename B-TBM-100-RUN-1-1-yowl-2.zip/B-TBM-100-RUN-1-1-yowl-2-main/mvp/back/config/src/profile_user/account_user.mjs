import { dbconnect } from '../connect_user/connect.mjs'

export async function accountuser(req, res){
  try {
    const user_id = req.user.user_id 

    const db = await dbconnect()

    await db.query(
      'SELECT username, email, profile_description FROM user WHERE user_id = ?'
    )

    res.status(201).json({ success: true })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Database error' })
  }
};