import jwt from "jsonwebtoken"

export async function midWare(req, res, next) {
    let token = req.header("Authorization");
    const secret = process.env.SECRET;

    if (!token) {
        return res.status(400).json({ success: false, msg: "No token" });
    }

    if (token.startsWith("Bearer ")) {
        token = token.slice(7);
    }

    try {
        const decoded = jwt.verify(token, secret);
        if (!decoded || !decoded.user_id) {
            return res.status(400).json({ success: false, msg: "token not valid" });
        }

        req.userId = decoded.user_id; 
        next(); 
    } catch (error) {
        console.error("JWT verify error:", error);
        return res.status(401).json({ success: false, msg: "token not valid" });
    }
}
