import { token } from './token.mjs';
import { hashpassword } from './hashpassword.mjs';
import mysql2 from 'mysql2/promise';


export async function test() {
    const connection = await mysql2.createConnection({
        host: '127.0.0.1',
        user: 'root',
        password: '98765',
        database: 'yowl_db',
        port: 6060
    }); 

    const data = {
        email: "hug@gm,,;,;l.com",
        password:"coco",
        username:"cata",
    }

    const query2 = "INSERT INTO user (email, password, username) Values (?, ?, ?)";
    const hash = await hashpassword(data.password);
    const elem = [data.email, hash, data.username];
    await connection.execute(query2, elem);
}

test();