import jwt from "jsonwebtoken";

export function userToken(id) {
    const secret = process.env.SECRET;
    const tok = jwt.sign({user_id: id}, secret);
    return tok;
}