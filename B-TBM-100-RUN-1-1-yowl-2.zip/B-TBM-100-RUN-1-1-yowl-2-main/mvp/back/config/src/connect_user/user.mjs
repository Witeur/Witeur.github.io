import express from "express";

import { loginUser } from "./login.mjs";
import { register } from "./register.mjs";
import { display_achievement } from "../achievement_user/display_achievement_user.mjs";
import { unlock_achievement } from "../achievement_user/unlock_achievement_user.mjs";
import { display_unlocked_achievements } from "../achievement_user/display_unlocked_achievement_user.mjs";
import { createpost } from "../post_user/create_post.mjs";
import { deletepost } from "../post_user/delete_post.mjs";
import { editpost } from "../post_user/edit_post.mjs";
import { getpost } from "../post_user/get_post.mjs";
import { searchpost } from "../post_user/search_post.mjs";
import { accountuser } from "../profile_user/account_user.mjs";
import { midWare } from "../authent/midWare.mjs";

export const router = express.Router();

router.post("/login", loginUser);
router.post("/register",  register);
router.get("/display", display_achievement);
router.post("/unlockachievement", midWare, unlock_achievement);
router.get("/displayunlocked", midWare, display_unlocked_achievements);
router.post("/createpost", midWare, createpost);
router.delete("/deletepost", midWare, deletepost);
router.put("/editpost", midWare, editpost);
router.get("/getpost", getpost);
router.get("/searchpost", searchpost);
router.get("/accountuser", midWare, accountuser);

export default router;
