import { dbconnect } from "./connect.mjs";
import { userToken } from "./token.mjs";
import bcrypt from "bcrypt";

export async function loginUser(req, res) {
    try {
        const data = req.body;
        const connect = await dbconnect();


        const querySQL = "SELECT email, password, id FROM user WHERE email= ?";
        const [rows] = await connect.execute(querySQL, [data.email]);

        if (!rows.length) {
            return res.status(400).json({ success: false, msg: "User not found" });
        }

        const user = rows[0];

        
        const passCompare = await bcrypt.compare(data.password, user.password);
        if (!passCompare) {
            return res.status(400).json({ success: false, msg: "Invalid password" });
        }

    
        const tok = userToken(user.id);

        
        return res.status(200).json({ token: tok, id: user.id, success: true });

    } catch (error) {
        return res.status(500).json({ success: false, msg: "Server error" });
    }
}
