import mysql from 'mysql2/promise';
let pool;
export async function dbconnect(){
    if (!pool) {
      pool = mysql.createPool({
        host: process.env.MYSQL_HOST, 
        user: 'root',
        password: process.env.MYSQL_ROOT_PASSWORD, 
        database: process.env.MYSQL_DATABASE, 
        port: process.env.PORT,
        waitForConnections: true,
    });
  }
    return pool;
}