import { userToken } from "./token.mjs";
import { dbconnect } from "./connect.mjs";
import { hashpassword } from "./hashpassword.mjs";

export async function register(req, res) {
    try {
        const data = req.body;
        
        const connect = await dbconnect();

        if (data.password === "") {
            const result = { "sucess": false, "msg": "No password" };
            return res.status(400).json(result);
        }

        const query1 = "SELECT COUNT(email) AS countEmail FROM user WHERE email= ?";
        const email = [data.email];
        const [count] = await connect.execute(query1, email);
        const nb = count[0].countEmail;

        if (nb > 0) {
            const result = { "success": false, "mesg": "This user is already register" };
            return res.status(400).json(result);
        } else {
            const query2 = "INSERT INTO user (email, password, username) Values (?, ?, ?)";
            const hash = await hashpassword(data.password);
            const elem = [data.email, hash, data.pseudonym];
           const [wait] =  await connect.execute(query2, elem);
           const id = wait.insertId;
           

            const token = userToken(id);
            const resultJSON = { "succes": true, id: id, "token": token };
            return res.status(200).json(resultJSON);
        }
    } catch (error) {
        const resultJSON = { "succes": false, "msg": "error serv" };
        return res.status(500).json(resultJSON);

    }

}