import bcrypt from "bcrypt";

export async function hashpassword(password) {
    try {
        const saltRounds = 12
        const salt = await bcrypt.genSalt(saltRounds);
        const hashed = await bcrypt.hash(password, salt);
        return hashed;
    } catch(error) {
        console.error("Erreur pendant le hashing: ", error);
        throw error;
    }
}