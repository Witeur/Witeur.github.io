import { dbconnect } from '../connect_user/connect.mjs'


export async function display_unlocked_achievements(req, res) {
  try {
    const user_id = req.userId      
    const db = await dbconnect()

    const [rows] = await db.query(
      `SELECT um.user_id, um.mission_id, m.title, m.description, um.completed_at
       FROM user_mission um
       JOIN mission m ON um.mission_id = m.mission_id
       WHERE um.user_id = ?`,
      [user_id]
    )

    res.status(200).json({ achievements: rows })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Database error' })
  }
}