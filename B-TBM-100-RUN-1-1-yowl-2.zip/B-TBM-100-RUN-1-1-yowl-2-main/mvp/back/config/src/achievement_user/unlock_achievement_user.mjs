import { dbconnect } from '../connect_user/connect.mjs'


export async function unlock_achievement(req, res) {
  try {
    const { mission_id } = req.body;
    const user_id = req.userId;

    if (!mission_id) {
      return res.status(400).json({ error: 'Mission ID is required' });
    }

    const db = await dbconnect();
    let result; 

    try {
      [result] = await db.query(
        'INSERT IGNORE INTO user_mission (user_id, mission_id) VALUES (?, ?)',
        [user_id, mission_id]
      );
    } catch (err) {
      return res.status(500).json({ error: 'Database error' });
    }

    res.status(200).json({ success: true, unlocked: result.affectedRows === 1 });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
}





