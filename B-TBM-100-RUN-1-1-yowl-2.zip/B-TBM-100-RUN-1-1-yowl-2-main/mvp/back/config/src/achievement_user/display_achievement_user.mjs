
import { dbconnect } from '../connect_user/connect.mjs'

export async function display_achievement (req, res) {
  try {
    const db = await dbconnect();

    const [missions] = await db.query(
      'SELECT mission_id, title, description FROM mission'
    );

    res.status(200).json(missions);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
};
