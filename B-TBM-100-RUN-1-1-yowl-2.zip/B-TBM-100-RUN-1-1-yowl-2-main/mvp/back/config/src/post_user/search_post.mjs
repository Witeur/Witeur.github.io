import { dbconnect } from '../connect_user/connect.mjs'

export async function searchpost (req, res) {
  try {
    const { keyword } = req.query 

    if (!keyword) {
      return res.status(400).json({ error: 'Keyword is required' })
    }
    const db = await dbconnect();

    const [posts] = await db.query(
      'SELECT id, title, sub_title, content, user_id, created_at FROM post WHERE title LIKE ? OR sub_title LIKE ? OR content LIKE ? ORDER BY created_at DESC'
    ,
      [`%${keyword}%`, `%${keyword}%`, `%${keyword}%`]
    )


    res.status(200).json(posts);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
};