
import { dbconnect } from '../connect_user/connect.mjs'

export async function createpost(req, res){
  try {
    const { title, content, sub_title } = req.body
    const user_id = req.userId; 

    const db = await dbconnect()

    const [result] = await db.query(
      'INSERT INTO post (title, sub_title, content, user_id) VALUES (?, ?, ?, ?)',
      [title, sub_title || null, content, user_id]
    )

    const newPost = {
      id: result.insertId,
      title,
      sub_title,
      content,
      user_id
    }

    res.status(201).json({ success: true, post: newPost })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Database error' })
  }
};




