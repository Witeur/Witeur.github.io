
import { dbconnect } from '../connect_user/connect.mjs'

export async function getpost (req, res) {
  try {
    const db = await dbconnect();

    const [posts] = await db.query(
      'SELECT id, title, sub_title, content, user_id, created_at FROM post ORDER BY created_at DESC'
    );

    res.status(200).json(posts);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
};

