import { dbconnect } from '../connect_user/connect.mjs'

export async function deletepost(req, res) {
  try {
    const { id } = req.body
    const user_id = req.user.user_id

    if (!id) {
      return res.status(400).json({ error: 'Post ID is required' })
    }

    const db = await dbconnect()

    const [result] = await db.query(
      'DELETE FROM post WHERE user_id = ? AND id = ?',
      [user_id, id]
    )

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Post not found or not yours' })
    }

    res.status(200).json({ success: true })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Database error' })
  }
}
