import { dbconnect } from '../connect_user/connect.mjs'

export async function editpost (req, res) {
  try {
    const { id, title, content, sub_title } = req.body;
    const user_id = req.user.user_id

    const db = await dbconnect()

    const result = await db.query(
      'UPDATE post SET title = ?, sub_title = ?, content = ? WHERE id = ? and user_id = ?',
      [title, sub_title || null, content, id, user_id]
    )
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Post not found or not yours' })
    }

    res.status(200).json({ success: true })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Database error' })
  }
}