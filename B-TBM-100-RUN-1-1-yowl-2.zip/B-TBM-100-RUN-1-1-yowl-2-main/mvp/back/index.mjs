import dotenv from 'dotenv';
import express from 'express';
import router from './config/index.router.mjs';
import cors from 'cors';
dotenv.config();
const mvp = express();
const port = 4242

mvp.use(cors({
  origin: 'http://localhost:4000',
  methods: ['GET','POST','PUT','DELETE','OPTIONS'],
  credentials: true
}));
mvp.use(express.json());

mvp.use("/config", router);

mvp.listen(port, () => {
  console.log(`Server running on port 4242 : http://localhost:${port}`);
});
