export async function registerUser(pseudonym, email, password) {
  const response = await fetch("http://localhost:4242/config/register", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      pseudonym,
      email,
      password
    })
  });

  const data = await response.json();


  if (!response.ok) {
    throw new Error(data.msg || data.message || "Registration failed");
  }
  
  localStorage.setItem("token", data.token); 
  localStorage.setItem("userId", data.id);

  


  return data;
}
