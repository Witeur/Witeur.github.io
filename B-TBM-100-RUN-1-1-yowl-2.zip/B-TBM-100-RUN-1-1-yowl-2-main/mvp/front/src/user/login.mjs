export async function loginUser(email, password) {
  const response = await fetch("http://localhost:4242/config/login", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      email,
      password
    })
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.msg || data.message || "Login failed");
  }
  
  localStorage.setItem("token", data.token); 
  localStorage.setItem("userId", data.id);


  return data;
}
