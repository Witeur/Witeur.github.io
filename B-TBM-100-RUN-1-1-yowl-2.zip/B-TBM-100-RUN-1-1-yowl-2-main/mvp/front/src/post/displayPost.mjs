export async function getTopics() {
  const response = await fetch("http://localhost:4242/config/getpost", {
    method: "GET",
    headers: {
      "Authorization": `Bearer ${localStorage.getItem("token")}`
    }
  });
 
  const data = await response.json();
 
  if (!response.ok) {
    throw new Error(data.msg || data.message || "Failed to fetch topics.");
  }
 
  return data;
}