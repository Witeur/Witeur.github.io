export async function sendTopicRequest(title, sub_title, content) {

  const response = await fetch("http://localhost:4242/config/createpost", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${localStorage.getItem("token")}`,
      "id": localStorage.getItem("userId") 
    },
    
    body: JSON.stringify({
      title,
      sub_title,
      content
    })
  });

  

  let data;

  try {
    data = await response.json();
  } catch (e) {
    throw new Error("The server returned a non‑JSON response (likely a 500 Internal Server Error).");
  }


  if (!response.ok) {
    throw new Error(data.msg || data.message || "Failed to send the topic.");
  }

  return data;
}