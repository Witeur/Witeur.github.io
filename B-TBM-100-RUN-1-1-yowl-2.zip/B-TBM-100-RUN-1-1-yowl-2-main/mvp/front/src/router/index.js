import { createRouter, createWebHistory } from 'vue-router'

import Login from '../pages/login.vue'
import Register from '../pages/register.vue'
import Homecon from '../pages/home-con.vue'
import Homedis from '../pages/home-dis.vue'
import Achievements from '../pages/achievements.vue'
import Settings from '../pages/settings.vue'


const routes = [
  { path : '/', name: 'home-dis', component : Homedis},
  { path : '/home', name: 'home-con', component : Homecon},
  { path: '/login', name: 'login', component: Login },
  { path: '/register', name: 'register', component: Register },
  { path: '/achievements', name: 'achievements', component: Achievements},
  { path: '/settings', name: 'settings', component: Settings}
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router