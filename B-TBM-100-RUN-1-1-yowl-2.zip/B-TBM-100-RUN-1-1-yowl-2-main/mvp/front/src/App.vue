<script setup>
import { onMounted } from 'vue'
import { loadAchievements } from './achievements/achievementsState'

onMounted(() => {
  loadAchievements()
})
</script>

<template>
  <router-view />
</template>
