<template>
  <div class="container" :style="{ backgroundImage: `url(${assets.bg})` }">
    <div class="headband">
      <img :src="assets.logo" alt="Mon image" class="my-image" />
      <span>Quest Network</span>

      <div class="search-container">
        <input type="text" placeholder="No girlfriend ?" class="search-bar" />
        <button class="search-button">🔍</button>
      </div>

      <!-- Groupe des boutons à droite -->
      <div class="right-buttons">
        <button class="button-challenge" @click="$router.push('/achievements')">
          <img :src="assets.trophy" class="icon" />
        </button>

        <button class="button-notification" @click="openPopup('notification')">
          <img :src="assets.notification" class="icon" />
        </button>

        <button class="button-settings" @click="$router.push('/settings')">
          <img :src="assets.setting" class="icon-large" />
        </button>


        <button class="button-profile" @click="openPopup('profile')">
          <img :src="assets.profile" class="icon" />
        </button>

      </div>
    </div>

    <div class="bottom-row">
      <div class="left-box">
        <div class="box-new-popular">
          <button class="button-new">
            <span>
              <img :src="assets.newpaper" class="icon-new">
              <h3 class="new-popular-text">New</h3>
            </span>
          </button>
          <button class="button-popular">
            <span>
              <img :src="assets.fire" class="icon-new">
              <h3 class="new-popular-text">Popular</h3>
            </span>
          </button>
        </div>
        <div class="box-topic">
          <div class="button-topic" @click="openPopup('topic')">
            <span>
              <img :src="assets.add" class="icon-new">
              <h2 class="topic-text">Create a custom Topic</h2>
            </span>
          </div>
        </div>

        <div class="box-history-feed"></div>
      </div>
      <div class="middle-space"></div>
      <div class="right-box">
        <div v-for="value in topics" :key="value.id">
          <h2>{{ value.title }}</h2>
          <h3>{{ value.sub_title }}</h3>
          <p>{{ value.content }}</p>
        </div>
      </div>
      <div class="middle-space"></div>
    </div>
    <!-- Overlay -->
    <div v-if="activePopup" class="overlay" @click="closePopup"></div>

    <!-- Popup Notification -->
    <div v-if="activePopup === 'notification'" class="popup-notifacation">
      <h3>Notifications</h3>
      <p>Aucune notification pour le moment.</p>
      <button @click="closePopup" class="X">X</button>
    </div>
    <!-- Popup Crate a custom Topic -->
    <div v-if="activePopup === 'topic'" class="popup-create">
      <h3>Create a custom Topic</h3>

      <form class="formulaire">
        <div>
          <h4>The title</h4>
          <input type="text" placeholder="between the title" v-model="title" />
        </div>

        <div>
          <h4>The second title</h4>
          <input type="text" placeholder="between the second title" v-model="sub_title" />
        </div>

        <div>
          <h4>Add a comment...</h4>
          <textarea placeholder="Write something..." maxlength="250" v-model="content"></textarea>
        </div>
      </form>
      <button @click="closePopup" class="X">X</button>
      <button @click="sendTopic" :disabled="loading" class="submit-btn">
        {{ loading ? 'Send the Topic...' : 'Send' }}
      </button>
    </div>
    <!-- Popup Profil -->
    <div v-if="activePopup === 'profile'" class="popup-profil">
      <div>
        <div class="popup-avatar">
          <img :src="assets.profile" class="popup-avatar-img" alt="Avatar utilisateur" />
        </div>
        <h2 class="popup-texte">Profil</h2>
      </div>
      <div>
        <p class="popup-texte-texte-name-age">Name : Enzo</p>
        <p class="popup-texte-texte-name-age">Age : 8</p>
      </div>
      <div>
        <p>Mood : good</p>
      </div>
      <div>
        <p>Description : ☟⚐🕈 🕈⚐☠👎☜☼☞🕆☹. </p>
      </div>
      <div> </div>
      <button class="logout-button" @click="logout">
  Se déconnecter
</button>

      <button @click="closePopup" class="X">X</button>
    </div>

  </div>
</template>

<script>
import '../pages/styles/main.css'
import logo from '../assets/logo-social-network.png';
import bg from '../assets/photo-background.png';
import notification from '../assets/notification.png';
import setting from '../assets/Copilot_20260119_092432.png';
import trophy from '../assets/trophy.png';
import profile from '../assets/profile.png';
import newpaper from '../assets/newspaper.png';
import fire from '../assets/fire.png';
import add from '../assets/+.png'
import { sendTopicRequest } from '../post/creatpost.mjs';
import { getTopics } from '../post/displayPost.mjs';

export default {
  name: 'App',
 
  data() {
    return {
      assets: { logo, bg, notification, setting, trophy, profile, newpaper, fire, add },
      activePopup: null,
      title: '',
      sub_title: '',
      content: '',
      loading: false,
      topics: []
    };
  },
 
  async mounted() {
    try {
      this.topics = await getTopics()
    } catch (err) {
      console.error("Erreur lors du GET :", err)
    }
  },
 
  methods: {
    openPopup(type) {
      this.activePopup = type;
    },
 
    closePopup() {
      this.activePopup = null;
    },
 
    logout() {
      localStorage.removeItem("token");
      localStorage.removeItem("userId");
      this.activePopup = null;
      this.$router.push("/login");
    },
 
    async sendTopic() {
      this.loading = true;
 
      try {
        const data = await sendTopicRequest(
          this.title,
          this.sub_title,
          this.content,
        );
        this.topics = await getTopics();
        this.closePopup();
 
        this.title = "";
        this.sub_title = "";
        this.comment = "";
      } catch (err) {
        console.error("Erreur :", err);
      }
 
      this.loading = false;
    }
  }
};
 
</script>

<style>
.submit-btn {

  position: absolute;

  bottom: 80px;

  right: 12px;

  color: #FFDE21;

  background: none;

  border: 2px solid rgba(255, 255, 255, 0.15);

  font-size: 22px;

  cursor: pointer;

}


.logout-button {
  background: none;
  border: 2px solid rgba(255, 255, 255, 0.15);
  font-size: 22px;
  cursor: pointer;
  margin-left: 50px;
  color: #c71535;
  border-radius: 80px;
}
.formulaire {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.formulaire h4 {
  color: #fff;
  font-size: 14px;
}

.formulaire input,
.formulaire textarea {
  background: rgba(7, 13, 36, 0.616);
  border: none;
  border-radius: 14px;
  padding: 12px;
  color: #fff;
}

.formulaire textarea {
  min-height: 120px;
  resize: none;
}

.formulaire ::placeholder {
  color: rgba(255, 255, 255, 0.8);
}

.X {
  position: absolute;
  top: 12px;
  right: 12px;

  color: #FFDE21;
  background: none;
  border: 2px solid rgba(255, 255, 255, 0.15);
  font-size: 22px;
  cursor: pointer;
}

.popup-texte-texte-name-age {
  text-align: center;

}

.icon {
  height: 60%;
}

.icon-large {
  height: 120%;
}

.container {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100vh;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  background-attachment: fixed;
  overflow: hidden;
  z-index: 1;
}

/* Header fixe */
.headband {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;

  display: flex;
  gap: 10px;
  align-items: center;
  justify-content: flex-start;

  padding: 12px 24px;
  background: rgba(10, 16, 40, 0.85);
  border-bottom: 1px solid rgba(255, 255, 255, 0.15);
  color: #E6E8F0;
  backdrop-filter: blur(6px);

  font-family: "Orbitron";
  font-size: 2rem;

  z-index: 1000;
}

.headband span {
  color: #FFDE21;
}

.my-image {
  width: 95px;
  height: auto;
}

/* Bottom row */
.bottom-row {
  position: absolute;
  top: 90px;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  height: calc(100vh - 90px);
}

.left-box {
  margin-top: 30px;
  flex: 0 0 15%;
  background-color: rgba(10, 16, 40, 0.75);
  border: 1px solid rgba(255, 255, 255, 0.15);
  display: flex;
  flex-direction: column;
  height: 100%;
}

.middle-space {
  flex: 0 0 18%;
  background-color: transparent;
}

.right-box {
  margin-top: 30px;
  flex: 1;
  background-color: rgba(10, 16, 40, 0.55);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-top: transparent;
}

/* Styles pour la barre de recherche et le bouton */
.search-container {
  display: flex;
  align-items: center;
  max-width: 25rem;
  width: 100%;
  margin-left: auto;
  margin-right: auto;
}

.search-icon {
  height: 10px;
  width: 20px;
  position: center;
  font-size: 2.6rem;
}


.search-bar {
  flex: 1;
  height: 1.9375rem;
  border-radius: 50px 0 0 50px;
  border: 0.0625rem solid #ccc;
  border-right: none;
  padding: 0 0.75rem;
  outline: none;
  font-size: 1rem;
}

.search-button {
  height: 2.0625rem;
  width: 2.5rem;
  border-radius: 0 50px 50px 0;
  border: 0.0625rem solid #ccc;
  border-left: none;
  background-color: #FFDE21;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.25rem;
}

.right-buttons {
  margin-left: auto;
  display: flex;
  align-items: center;
  gap: 12px;
}

.right-buttons button {
  width: 2.5rem;
  height: 2.5rem;
  border-radius: 50%;
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
}

.button-profile,
.button-settings,
.button-notification,
.button-challenge {
  background-color: transparent;
  cursor: pointer;
}

.icon {
  height: 60%;
}

.box-new-popular {
  margin-top: 0;
  width: 100%;
  height: 20%;
  background-color: rgba(10, 16, 40, 0.75);
  border-block-end: 1px solid rgba(255, 255, 255, 0.15);
}

.box-topic {
  margin-top: 0;
  width: 100%;
  height: 10%;
  background-color: rgba(10, 16, 40, 0.75);
  border-block-end: 1px solid rgba(255, 255, 255, 0.15);
}

.box-history-feed {
  margin-top: 0;
  width: 100%;
  height: 100%;
  flex: 1;
  background-color: rgba(10, 16, 40, 0.75);
  border-block-end: 1px solid rgba(255, 255, 255, 0.15);
}

.button-new {
  margin-top: 0;
  width: 100%;
  height: 50%;
  flex: 1;
  background-color: transparent;
  border-bottom: 0.1px solid rgba(255, 255, 255, 0.15);
  border-left: none;
  border-right: none;
  border-top: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
}

.button-popular {
  margin-top: 0;
  width: 100%;
  height: 50%;
  flex: 1;
  background-color: transparent;
  border-bottom: 0.1px solid rgba(255, 255, 255, 0.15);
  border-left: none;
  border-right: none;
  border-top: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
}

.button-topic {
  margin-top: 0;
  width: 100%;
  height: 100%;
  flex: 1;
  background-color: transparent;
  border-bottom: 1px solid rgba(255, 255, 255, 0.15);
  border-left: none;
  border-right: none;
  border-top: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
}

.button-new span {
  display: flex;
  align-items: center;
  gap: 10px;
}

.icon-new {
  height: 40px;
}

.new-popular-text {
  margin: 0;
  font-size: 1.4rem;
  color: white;
}

.button-popular span {
  display: flex;
  align-items: center;
  gap: 10px;
}

.button-topic span {
  display: flex;
  align-items: center;
  gap: 10px;
}

.topic-text {
  margin: 0;
  font-size: 1rem;
  color: white;
}

.overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.4);
  z-index: 10;
}

.popup-notifacation {
  position: fixed;
  top: 220px;
  left: 91%;
  transform: translate(-50%, -50%);
  background: rgba(10, 16, 40, 0.75);
  border: 1px solid rgba(255, 255, 255, 0.15);
  padding: 20px;
  border-radius: 12px;
  color: white;
  min-width: 280px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
  z-index: 11;
  animation: fadeIn 0.2s ease-out;
}

.popup-create {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: rgba(10, 16, 40, 0.9);
  border: 1px solid rgba(255, 255, 255, 0.15);
  padding: 24px;
  border-radius: 14px;
  color: white;
  width: 360px;
  max-width: 90vw;
  z-index: 20;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.4);
}


.popup-profil{
  position: fixed;
  top: 290px;
  left: 91%;
  transform: translate(-50%, -50%);

  width: 280px;
  min-height: 220px;
  /* 👈 petit mais suffisant */
  padding: 16px 16px 56px;
  /* 👈 espace pour le bouton */

  background: rgba(10, 16, 40, 0.75);
    border: 1px solid rgba(255, 255, 255, 0.15);
  padding: 20px;
  border-radius: 12px;
  color: white;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
  z-index: 1000;
  animation: fadeIn 0.2s ease-out;
}

.popup-avatar {
  display: flex;
  justify-content: center;
  margin-bottom: 12px;
}

.popup-avatar-img {
  width: 70px;
  height: 70px;
  border-radius: 50%;
  background-color: black;
}

.popup-texte {
  display: flex;
  justify-content: center;
  gap: 10px;
  text-align: center;
}

.popup-texte p {
  margin: 0;
}



@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translate(-50%, -60%);
  }

  to {
    opacity: 1;
    transform: translate(-50%, -50%);
  }
}

@media (max-width: 768px) {


  .bottom-row {
    display: flex;
    flex-direction: row;
  }


  .left-box {
    flex: 0 0 56px;
    min-width: 56px;
    margin-top: 20px;
  }

  /* .left-box h2,
  .left-box h3,
  .left-box span {
    display: none;
  } */

  .icon-new {
    height: 26px;
  }

  .button-new,
  .button-popular,
  .button-topic {
    justify-content: center;
    padding: 0;
  }

  .middle-space {
    flex: 0 0 4px;
  }

  .right-box {
    flex: 1;
    margin-top: 20px;
    min-width: 0;
  }


  .headband {
    font-size: 1.4rem;
    padding: 8px 12px;
  }

  .my-image {
    width: 60px;
  }


  .search-container {
    position: static;
    width: 90%;
    margin: 8px auto;
  }
}


@media (max-width: 480px) {

  .left-box {
    flex: 0 0 50px;
  }

  .icon-new {
    height: 24px;
  }

  .right-buttons button {
    width: 2rem;
    height: 2rem;
  }
}
</style>