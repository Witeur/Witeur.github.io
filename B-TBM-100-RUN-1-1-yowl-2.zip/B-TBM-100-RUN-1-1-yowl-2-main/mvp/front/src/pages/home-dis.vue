<template>
  <div class="container" :style="{ backgroundImage: `url(${assets.bg})` }">
    <div class="headband">
      <img :src="assets.logo" alt="Mon image" class="my-image" />
      <span>Quest Network</span>

      <div class="search-container">
        <input
          type="text"
          placeholder="No girlfriend ?"
          class="search-bar"
        />
        <button class="search-button">🔍</button>
      </div>

      <!-- Groupe des boutons à droite -->
        <router-link to="/register" class="logo-link">
        <span>Register</span>
      </router-link>
      <router-link to="/login" class="logo-link">
        <span>Login</span>
      </router-link>
    </div>

    <div class="bottom-row">
      <div class="left-box">
        <div class="box-new-popular">
          <button class="button-new">
            <span>
              <img :src="assets.newpaper" class="icon-new">
              <h3 class="new-popular-text">New</h3>
            </span>
          </button>
          <button class="button-popular">
            <span>
              <img :src="assets.fire" class="icon-new">
              <h3 class="new-popular-text">Popular</h3>
            </span>
          </button>
        </div>
        <div class="box-history-feed"></div>
      </div>
      <div class="middle-space"></div>
      <div class="right-box"></div>
      <div class="middle-space"></div>
    </div>
        <!-- Overlay -->
    <div v-if="activePopup" class="overlay" @click="closePopup"></div>

    <!-- Popup Notification -->
    <div v-if="activePopup === 'notification'" class="popup-notifacation">
      <h3>Notifications</h3>
      <p>No notifications for now.</p>
      <button @click="closePopup"class="X">X</button>
    </div>

    <!-- Popup Profil -->
    <div v-if="activePopup === 'profile'" class="popup-profil">
      <div> 
        <div class="popup-avatar">
          <img :src="assets.profile" class="popup-avatar-img" alt="Avatar utilisateur" />
        </div>
        <h2 class="popup-texte">Profil</h2>
      </div>
      <div> 
      <p class="popup-texte-texte-name-age">Name : John</p>
      <p class="popup-texte-texte-name-age">Age : 21</p>
      </div>
      <div> 
        <p>Mood : good</p>
      </div>
      <div>
        <p>Description : ☟⚐🕈 🕈⚐☠👎☜☼☞🕆☹. </p> </div>
      <div> </div>
      <button class="logout-button" @click="logout">
  Se déconnecter
</button>

      <button @click="closePopup" class="X">X</button>
    </div>

  </div>
</template>

<script>
import '../pages/styles/main.css'
import logo from '../assets/logo-social-network.png';
import bg from '../assets/photo-background.png';
import notification from '../assets/notification.png';
import setting from '../assets/Copilot_20260119_092432.png';
import trophy from '../assets/trophy.png';
import profile from '../assets/profile.png';
import newpaper from '../assets/newspaper.png';
import fire from '../assets/fire.png';
import add from '../assets/+.png'

export default {
  name: 'App',

  data() {
    return {
      assets: { logo, bg, notification, setting, trophy, profile, newpaper, fire, add },
    activePopup: null
    };
  },

  methods: {
   openPopup(type) {
      this.activePopup = type;
    },

    closePopup() {
      this.activePopup = null;
    }
  }
};
</script>

<style>
.logout-button{
   background: none;
  border: 2px solid rgba(255, 255, 255, 0.15);
  font-size: 22px;
  cursor: pointer;
  margin-left: 50px;
  color: #E6E8F0;
  border-radius:80px ;
}
.formulaire {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.formulaire h4 {
  color: #fff;
  font-size: 14px;
}

.formulaire input,
.formulaire textarea {
  background: rgba(7, 13, 36, 0.616);
  border: none;
  border-radius: 14px;
  padding: 12px;
  color: #fff;
}

.formulaire textarea {
  min-height: 120px;
  resize: none;
}

.formulaire ::placeholder {
  color: rgba(255, 255, 255, 0.8);
}

.X {
  position: absolute;
  top: 12px;
  right: 12px;

  color: #FFDE21;
  background: none;
  border: 2px solid rgba(255, 255, 255, 0.15);
  font-size: 22px;
  cursor: pointer;
}

.popup-texte-texte-name-age{
text-align: center;

}
.icon{
  height: 60%;
}
.icon-large{
  height: 120%;
}
.container {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100vh;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  background-attachment: fixed;
  overflow: hidden;
  z-index: 1;
}

/* Header fixe */
.headband {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;

  display: flex;
  gap: 10px;
  align-items: center;
  justify-content: flex-start;

  padding: 12px 24px;
  background: rgba(10, 16, 40, 0.85);
  border-bottom: 1px solid rgba(255, 255, 255, 0.15);
  color: #E6E8F0;
  backdrop-filter: blur(6px);

  font-family: "Orbitron";
  font-size: 2rem;

  z-index: 1000;
}

.headband span {
  color: #FFDE21;
}

.my-image {
  width: 95px;
  height: auto;
}

/* Bottom row */
.bottom-row {
  position: absolute;
  top: 90px;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  height: calc(100vh - 90px);
}

.left-box {
  margin-top: 30px;
  flex: 0 0 15%;
  background-color: rgba(10, 16, 40, 0.75);
  border: 1px solid rgba(255, 255, 255, 0.15);
  display: flex;
  flex-direction: column;
  height: 100%;
}

.middle-space {
  flex: 0 0 18%;
  background-color: transparent;
}

.right-box {
  margin-top: 30px;
  flex: 1;
  background-color: rgba(10, 16, 40, 0.55);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-top: transparent;
}

/* Styles pour la barre de recherche et le bouton */
.search-container {
  display: flex;
  align-items: center;
  max-width: 25rem;
  width: 100%;
  margin-left: auto;
  margin-right: auto;
}
.search-icon{
height: 10px;
width: 20px;
position: center;
font-size: 2.6rem;
}

.search-bar {
  flex: 1;
  height: 1.9375rem;
  border-radius: 50px 0 0 50px;
  border: 0.0625rem solid #ccc;
  border-right: none;
  padding: 0 0.75rem;
  outline: none;
  font-size: 1rem;
}

.search-button {
  height: 2.0625rem;
  width: 2.5rem;
  border-radius: 0 50px 50px 0;
  border: 0.0625rem solid #ccc;
  border-left: none;
  background-color: #FFDE21;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.25rem;
}

.right-buttons {
  margin-left: auto;
  display: flex;
  align-items: center;
  gap: 12px;
}
.right-buttons button {
  width: 2.5rem;
  height: 2.5rem;
  border-radius: 50%;
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
}
.icon {
  height: 60%;
}

.box-new-popular {
  margin-top: 0;
  width: 100%;
  height: 20%;
  background-color: rgba(10, 16, 40, 0.75);
  border-block-end: 1px solid rgba(255, 255, 255, 0.15);
}
.button-new {
  margin-top: 0;
  width: 100%;
  height: 50%;
  flex: 1;
  background-color: transparent;
  border-bottom: 0.1px solid rgba(255, 255, 255, 0.15);
  border-left: none;
  border-right: none;
  border-top: none;
  cursor: pointer;
    display: flex; 
  align-items: center; 
  justify-content: center; 
  gap: 10px;
}
.button-popular {
  margin-top: 0;
  width: 100%;
  height: 50%;
  flex: 1;
  background-color: transparent;
  border-bottom: 0.1px solid rgba(255, 255, 255, 0.15);
  border-left: none;
  border-right: none;
  border-top: none;
  cursor: pointer;
    display: flex; 
  align-items: center; 
  justify-content: center; 
  gap: 10px;
}
.button-new span {
  display: flex;
  align-items: center;
  gap: 10px;
}
.icon-new {
  height: 40px;
}
.new-popular-text {
  margin: 0;
  font-size: 1.4rem;
  color: white;
}
.button-popular span {
  display: flex;
  align-items: center;
  gap: 10px;
}
.overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.4);
  z-index: 10;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translate(-50%, -60%); }
  to   { opacity: 1; transform: translate(-50%, -50%); }
}

@media (max-width: 1100px) {
  .left-box {
    display: none;
  }
  .right-box {
    width: 100%;
  }
}
</style>