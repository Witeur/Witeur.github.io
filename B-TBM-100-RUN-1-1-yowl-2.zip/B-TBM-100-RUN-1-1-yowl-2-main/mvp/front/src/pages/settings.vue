<template>
  <div
    class="page"
    :style="{ backgroundImage: `url(${background})` }"
  >
   <header class="header">
    <router-link to="/home" class="logo-link">
      <img :src='lg' alt='Logo' class='logo'/>
    </router-link>
      <span>Quest Network</span>
      <h1>Settings</h1>
      
    </header>
   <div class="box">
  <aside class="settings-sidebar">
  <ul>
    <li
      :class="{ active: activeSection === 'account' }"
      @click="activeSection = 'account'"
    >
      Account
    </li>

    <li
      :class="{ active: activeSection === 'customization' }"
      @click="activeSection = 'customization'"
    >
      Customization
    </li>

    <li
      :class="{ active: activeSection === 'notifications' }"
      @click="activeSection = 'notifications'"
    >
      Notifications
    </li>
  </ul>
</aside>


  <main class="settings-content">

  <section v-if="activeSection === 'account'">
  <h2>Account</h2>

  <label>Username</label>
  <input v-model="profile.username"/>

  <label>Email</label>
  <input v-model="profile.email"/>

  <label>Description</label>
  <input v-model="profile.description" />
</section>


  <section v-if="activeSection === 'customization'">
    <h2>Customization</h2>
    <p>Website Aspect</p>
  </section>

  <section v-if="activeSection === 'notifications'">
    <h2>Notifications</h2>
    <p>Email and push notification settings.</p>
  </section>
</main>
</div>
</div>
</template>

<script>
import '../pages/styles/main.css'
import bg from '../assets/photo-background.png'
import lg from '../assets/logo-social-network.png'

export default {
  name: 'Settings',

  data() {
    return {
      activeSection: 'account',
      background: bg,
      lg: lg,
      profile: {
        username: '',
        email: '',
        description:''
    }
  }
},

mounted() {
    this.fetchAccount()
  },

methods:{
    async fetchAccount() {
      try {
        const res = await fetch('http://localhost:4242/config/account', {
          credentials: 'include'
        })
        const data = await res.json()

        this.profile = data
      } catch (err) {
        console.error('Failed to fetch account', err)
      }
    }
}
}
</script>

<style scoped>

   .header {
  position: fixed;    
  height:125px; 
  top: 0;
  left: 0;
  right: 0;

  display: flex;
  gap: 10px;
  align-items: center;
  justify-content: flex-start;

  padding: 12px 24px;
  background: rgba(10, 16, 40, 0.85);
  border-bottom: 1px solid rgba(255, 255, 255, 0.15);
  color: #E6E8F0;
  backdrop-filter: blur(6px);

  font-family:"Orbitron";
  font-size: 2.0rem;

  z-index: 1000; }

.header h1 {
  line-height: 1;
  margin-left: auto;
  margin-right: auto;
}



.header span {
  color: #FFDE21;
}

.logo-link {
  display: flex;
  align-items: center;
}

.logo-link:hover {
  opacity: 0.85;
}

.page {
  padding-top: 125px;
   min-height: 100vh;
  background-size: cover;
  background-position: center;
  background-attachment: fixed;

  display: flex;
  flex-direction: column;
}

h1 {
  font-family : "Orbitron";
  font-size: 2.5rem;
  color: #FFDE21;
}

h2 {
  font-family: "Rajdhani";
  font-size: 1.2rem;
}

.box{
  top:125px;
  position:fixed;
  display:flex;
  flex: 1;
  width: 100%;
  height:100%;
  max-width: none;
  padding-top: 20px;

  border-radius: 0;
  background-color: #e6e8f02d;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
  border-left: 6px solid #FFDE21;

  width: 100vw;
}

.box h1 {
  text-align: center;
}

.settings-sidebar {
  height:100%;
  width: 260px;
  background: rgba(10, 16, 40, 0.85);
  color: #E6E8F0;

  padding: 30px 20px;
  border-right: 1px solid rgba(255, 255, 255, 0.15);
}

.settings-sidebar ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.settings-sidebar li {
  padding: 12px 16px;
  margin-bottom: 10px;
  cursor: pointer;
  font-family: "Rajdhani";
  font-size: 1.1rem;
  border-radius: 6px;
}

.settings-sidebar li:hover {
  background: rgba(255, 255, 255, 0.1);
}

.settings-sidebar li.active {
  background: #FFDE21;
  color: #000;
  font-weight: bold;
}

.settings-content {
  flex: 1;
  padding: 30px 40px;
}

input {
  display: block;
  width: 95%;
  margin-bottom: 10px;
  padding: 8px;
  font-family: 'Rajdhani';
  font-size: 1.2rem;

}

button {
  width: 98%;
  padding: 8px;
}

button:disabled {
  width: 98%;
  opacity: 0.6;
  cursor: not-allowed;
}

.error {
  color: red;
  margin-top: 10px;
}

.logo {
  width: 100px;
  height: 100px;
  object-fit: cover;
  border-radius: 6px;
}

</style>
