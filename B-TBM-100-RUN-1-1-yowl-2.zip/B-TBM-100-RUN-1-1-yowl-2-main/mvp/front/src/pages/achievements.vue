<template>
  <div class="page" :style="{ backgroundImage: `url(${background})` }">
    <header class="header">
      <router-link to="/home" class="logo-link">
        <img :src="lg" alt="Logo" class="logo" />
      </router-link>
      <span>Quest Network</span>
      <h1>Achievements</h1>
    </header>

    <div class="box">
      <div
        v-for="achievement in sortedAchievements"
        :key="achievement.mission_id"
        :class="['achievement-box', { locked: !achievement.unlocked }]"
      >
        <strong>{{ achievement.title }}</strong>
        <span>{{ achievement.description }}</span>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted, computed } from 'vue'
import '../pages/styles/main.css'
import bg from '../assets/photo-background.png'
import lg from '../assets/logo-social-network.png'

export default {
  name: 'Achievements',
  setup() {
    const achievements = ref([])         
    const unlockedAchievements = ref([]) 

    const fetchAll = async () => {
  const res = await fetch('http://localhost:4242/config/display')
  if (!res.ok) {
    const text = await res.text()
    throw new Error(`Display fetch failed: ${text}`)
  } 
  achievements.value = await res.json()
}

const fetchUnlocked = async () => {
  const token = localStorage.getItem('token')
  if (!token) {
    unlockedAchievements.value = []
    return
  }

  const res = await fetch('http://localhost:4242/config/displayunlocked', {
    headers: { Authorization: `Bearer ${token}` }
  })
  if (!res.ok) {
    const text = await res.text()
    console.error('Unlock fetch failed:', res.status, text)
    unlockedAchievements.value = []
    return
  }
  const data = await res.json()
  unlockedAchievements.value = data.achievements
}

    const sortedAchievements = computed(() => {
      const unlockedIds = new Set(unlockedAchievements.value.map(a => a.mission_id))
      return achievements.value.map(a => ({
        ...a,
        unlocked: unlockedIds.has(a.mission_id)
      }))
      .sort((a, b) => a.unlocked - b.unlocked)
    })

    onMounted(async () => {
    try {
      await fetchAll()
      await fetchUnlocked()
    } catch (err) {
      console.error('Mounted hook failed:', err)
  }
})

    return {
      achievements,
      unlockedAchievements,
      sortedAchievements,
      background: bg,
      lg
    }
  }
}
</script>

<style scoped>
.header {
  position: fixed;
  height: 125px;
  top: 0;
  left: 0;
  right: 0;
  display: flex;
  gap: 10px;
  align-items: center;
  justify-content: flex-start;
  padding: 12px 24px;
  background: rgba(10, 16, 40, 0.85);
  border-bottom: 1px solid rgba(255, 255, 255, 0.15);
  color: #E6E8F0;
  backdrop-filter: blur(6px);
  font-family: "Orbitron";
  font-size: 2rem;
  z-index: 1000;
}

.header span {
  color: #FFDE21;
}

.header h1 {
  line-height: 1;
  margin-left: auto;
  margin-right: auto;
}

.logo-link {
  display: flex;
  align-items: center;
}

.logo-link:hover {
  opacity: 0.85;
}

.page {
  padding-top: 125px;
  min-height: 100vh;
  background-size: cover;
  background-position: center;
  background-attachment: fixed;
  display: flex;
  flex-direction: column;
}

h1 {
  font-family: "Orbitron";
  font-size: 2.5rem;
  color: #FFDE21;
}

.box {
  position: fixed;
  flex: 1;
  width: 100%;
  height: 100%;
  max-width: none;
  border-radius: 0;
  background-color: #e6e8f02d;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
  border-left: 6px solid #FFDE21;
  padding-top: 100px;
  width: 100vw;
}

.achievement-box {
  margin-left: 40px;
  width: 80vw;
  background-color: #FFDE21;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  font-family: "Rajdhani";
  font-size: 1.2rem;
  font-weight: 600;
  padding: 10px 20px;
  gap: 4px;
}

.achievement-box.locked {
  background-color: rgba(120, 120, 120, 0.4);
  color: #aaa;
  filter: grayscale(100%);
  opacity: 0.6;
}

.logo {
  width: 100px;
  height: 100px;
  object-fit: cover;
  border-radius: 6px;
}
</style>
