<template>
  <div
    class="page"
    :style="{ backgroundImage: `url(${background})` }"
  >
   <header class="header">
    <router-link to="/" class="logo-link">
      <img :src='lg' alt='Logo' class='logo'/>
    </router-link>
      <span>Quest Network</span>
     <router-link to="/register" class="logo-link">
        <span>Register</span>
      </router-link>
      <router-link to="/login" class="logo-link">
        <span>Login</span>
      </router-link>
    </header>
    <div class="box">
    <h2>The Sign - Up Form (Documentation)</h2>

    <form @submit.prevent="handleRegister">
      <input
        type="text"
        placeholder="Your Pseudonym"
        v-model="pseudonym"
        required
      />

      <input
        type="email"
        placeholder="Your Email"
        v-model="email"
        required
      />

      <input
        type="password"
        placeholder="Your Secret Password"
        v-model="password"
        required
      />

      <input
        type="password"
        placeholder="Confirm Your Secret Password"
        v-model="confirmPassword"
        required
      />

      <button type="submit" class="button" :disabled="loading">
        {{ loading ? 'Creating account...' : 'Register' }}
      </button>
    </form>

    <p v-if="error" class="error">Error, could not register</p>
    </div>
  </div>
</template>

<script>
import '../pages/styles/main.css'
import bg from '../assets/photo-background.png'
import lg from '../assets/logo-social-network.png'
import { registerUser } from '../user/register.mjs'

export default {
  name: 'Register',

  data() {
    return {
      pseudonym: '',
      email: '',
      password: '',
      confirmPassword: '',
      error: '',
      loading: false,
      background: bg,
      lg: lg
    }
  },

  methods: {
    async handleRegister() {
      this.error = ''

      if (this.password !== this.confirmPassword) {
        this.error = 'Passwords are not the same'
        return
      }

      this.loading = true

      try {
        await registerUser(
          this.pseudonym,
          this.email,
          this.password
        )

        this.$router.push('/home')

      } catch (err) {
        this.error = err.message
      } finally {
        this.loading = false
      }
    }
  }
}
</script>


<style scoped>

.header { 
  position: fixed;
  top: 0;
  left: 0;
  right: 0;

  display: flex;
  gap: 10px;
  align-items: center;
  justify-content: flex-start;

  padding: 12px 24px;
  background: rgba(10, 16, 40, 0.85);
  border-bottom: 1px solid rgba(255, 255, 255, 0.15);
  color: #E6E8F0;
  backdrop-filter: blur(6px);

  font-family:"Orbitron";
  font-size: 2.0rem;

  z-index: 1000; }

.header span {
  color: #FFDE21;
}

.header a:nth-last-child(2) {
  margin-left: auto;
  display: flex;  
}

.header a:last-child {
  margin-left: 20px;
}

.page {
  min-height: 100vh;
  background-size: cover;
  background-position: center;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

h2 {
  font-family: "Rajdhani";
  font-size: 1.2rem;
}

.logo-link {
  display: flex;
  align-items: center;
}

.logo-link:hover {
  opacity: 0.85;
}


.box{
     width: 100%;
  max-width: 600px;

  background: white;
  border-radius: 12px;
  padding: 20px;

  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
  border-left: 6px solid #FFDE21;

  display: flex;
  flex-direction: column;
  gap: 12px;
}

input {
  display: block;
  width: 95%;
  margin-bottom: 10px;
  padding: 8px;
  font-family: 'Rajdhani';
  font-size: 1.2rem;

}

button {
  width: 98%;
  padding: 8px;
}

button:disabled {
  width: 98%;
  opacity: 0.6;
  cursor: not-allowed;
}

.error {
  color: red;
  margin-top: 10px;
  font-family: 'Rajdhani';
  font-size: 1.2rem;
}

.button{
  font-family:'Rajdhani';
  font-size: 1.2rem
}

.logo {
  width: 100px;
  height: 100px;
  object-fit: cover;
  border-radius: 6px;
}
</style>
