import { unlockAchievement, getUserAchievements } from './achievementsService'

export const achievementsState = {
  unlocked: []
}

export async function loadAchievements() {
  achievementsState.unlocked = await getUserAchievements()
}
