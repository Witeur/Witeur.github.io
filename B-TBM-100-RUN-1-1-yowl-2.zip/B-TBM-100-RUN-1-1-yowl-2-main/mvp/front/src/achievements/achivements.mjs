export async function fetchMissions() {
  try {
    const response = await fetch('http://localhost:4242/config/display');
    if (!response.ok) {
      throw new Error('Error while fetching missions');
    }
    const missions = await response.json();
    console.log(missions);
    return missions;
  } catch (error) {
    console.error('Erreur :', error);
  }
}
