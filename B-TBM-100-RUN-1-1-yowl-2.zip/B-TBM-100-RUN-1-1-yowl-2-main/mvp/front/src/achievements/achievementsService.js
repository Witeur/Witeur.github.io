const API_URL = 'http://localhost:4242/mission'

export async function unlockAchievement(missionId) {
  const token = localStorage.getItem('token')

  await fetch(`${API_URL}/unlock`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({ mission_id: missionId })
  })
}

export async function getUserAchievements() {
  const token = localStorage.getItem('token')

  const res = await fetch(`${API_URL}/display`, {
    headers: {
      'Authorization': `Bearer ${token}`
    }
  })

  const data = await res.json()
  return data.missions
}
