
const API_URL = 'http://localhost:4242/config/unlockachievement';

export async function unlockAchievement(missionId) {
  const token = localStorage.getItem('token');
  if (!token) throw new Error('User not authenticated');

  const res = await fetch(API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      'id': localStorage.getItem('userId')
    },
    body: JSON.stringify({ mission_id: missionId })

  });

  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to unlock achievement');

  return data;
}