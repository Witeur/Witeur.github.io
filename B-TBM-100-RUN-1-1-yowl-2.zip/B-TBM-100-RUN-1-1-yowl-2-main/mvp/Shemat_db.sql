CREATE DATABASE IF NOT EXISTS yowl_db;
USE yowl_db;

CREATE TABLE IF NOT EXISTS user (
    id INT AUTO_INCREMENT,
    username VARCHAR(250) NOT NULL,
    password VARCHAR(250) NOT NULL,
    email VARCHAR(250) NOT NULL,
    profile_description TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS post (
    id INT AUTO_INCREMENT,
    title VARCHAR(250) NOT NULL,
    sub_title VARCHAR(250),
    content TEXT NOT NULL,
    user_id INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS user_relation (
    following_id INT NOT NULL,
    followed_id INT NOT NULL,
    followed_date DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    PRIMARY KEY (following_id, followed_id),
    FOREIGN KEY (following_id) REFERENCES user(id) ON DELETE CASCADE,
    FOREIGN KEY (followed_id) REFERENCES user(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS hashtag (
    hashtag_id INT AUTO_INCREMENT,
    name VARCHAR(250) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    PRIMARY KEY (hashtag_id)
);

CREATE TABLE IF NOT EXISTS post_hashtag (
    post_id INT NOT NULL,
    hashtag_id INT NOT NULL,
    PRIMARY KEY (post_id, hashtag_id),
    FOREIGN KEY (post_id) REFERENCES post(id) ON DELETE CASCADE,
    FOREIGN KEY (hashtag_id) REFERENCES hashtag(hashtag_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS mission (
    mission_id INT AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    PRIMARY KEY (mission_id)
);

CREATE TABLE IF NOT EXISTS user_mission (
    user_id INT NOT NULL,
    mission_id INT NOT NULL,
    completed_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    PRIMARY KEY (user_id, mission_id),
    FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
    FOREIGN KEY (mission_id) REFERENCES mission(mission_id) ON DELETE CASCADE
);

INSERT INTO mission (title, description)
VALUES
  (
    'FIRST TASK',
    'Create your first post'
  ),
  (
    'NEW EMPLOYEE',
    'Log into Quest Network for the first time'
  ),
  (
    'MISTAKES WERE MADE',
    'Delete a post'
  );


CREATE TABLE IF NOT EXISTS private_messages (
    message_id INT AUTO_INCREMENT,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    content TEXT NOT NULL,
    send_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    PRIMARY KEY (message_id),
    FOREIGN KEY (sender_id) REFERENCES user(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES user(id) ON DELETE CASCADE
);
