# Quest Network

## Overview

**Quest Network** is a social platform where users can register, log in, create posts, and unlock achievements. The app combines social networking with gamified user engagement through achievements, encouraging interaction and exploration.

---

## Link to Prototype

[View the Figma Prototype](https://www.figma.com/proto/rdnwzfJVUmOV5tIMKRKgcC/L-%C3%A9quipe-de-lucas.bouquain-team-library?node-id=0-1&t=O0jBzRVq6mqdkTPZ-1)

---

## Tech Stack & Technical Choices

- **Frontend:** Vue.js – reactive UI with component-based structure.
- **Backend:** Node.js with Express – lightweight, scalable REST API.
- **Database:** MySQL – structured storage of users, posts, and achievements.
- **Authentication:** JSON Web Tokens (jsonwebtoken) – secure, stateless authentication.
- **Password Hashing:** bcrypt – secure password storage.
- **Containerization:** Docker – ensures consistent environment for development, testing, and deployment.
- **Additional Packages:** cors (for cross-origin requests), dotenv (environment variables), nodemon (dev server auto-reload), and other necessary Node.js modules.

**Justification of Technical Choices:**

- **Vue.js**: Easy to maintain and extend, reactive, and integrates well with modern frontend workflows.  
- **Express + Node.js**: Lightweight and flexible for REST API, supports middleware for authentication and validation.  
- **JWT + bcrypt**: Provides secure and scalable user authentication without server-side session storage.  
- **Docker**: Simplifies setup, ensures environment consistency, and prepares the app for deployment.  

---

## Repository Structure


**Docs Structure Explanation:**

- **01_research/** – market and user research materials.  
- **02_personas/** – personas representing target users.  
- **03_user_journey/** – flow of user interactions.  
- **04_wireframes/** – low-fidelity UI sketches.  
- **05_mockups/** – high-fidelity UI designs.  
- **06_prototype/** – interactive Figma prototype.  
- **07_feedback/** – usability testing feedback.  
- **08_prioritization/** – MVP prioritization (MoSCoW/RICE).  
- **09_pitch/** – presentation materials.
- **mvp** - source code

---

## Installation and Run Instructions

### Using Docker (recommended)

 Build Docker images:
```bash
docker-compose build
```

 Start containers
```bash
docker-compose up
```

 Stop containers
```bash
docker-compose down
```


