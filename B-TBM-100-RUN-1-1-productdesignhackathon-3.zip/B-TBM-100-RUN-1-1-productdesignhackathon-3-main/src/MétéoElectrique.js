// Fonction pour formater et afficher uniquement les champs "dateheure" et "signal_horaire_couleur"
function formatSelectedData(data) {
    // Vérifie si les données sont dans la clé "results"
    const dataArray = data.results || data;
    if (!dataArray || !dataArray.length) {
        return "<p>Aucune donnée disponible dans 'results'.</p>";
    }

    // Crée le tableau HTML avec uniquement les champs souhaités
    let tableHTML = `
        <table border="1" style="border-collapse: collapse; width: 100%;">
            <thead>
                <tr>
                    <th>Date/Heure</th>
                    <th>Signal Horaire Couleur</th>
                </tr>
            </thead>
            <tbody>
                ${dataArray.map(row => `
                    <tr>
                        <td>${row.dateheure || 'N/A'}</td>
                        <td style="color: ${row.signal_horaire_couleur || 'black'}">${row.signal_horaire_couleur || 'N/A'}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
    return tableHTML;
}


async function recupMétéoElectrique() {
    const resultatElement = document.getElementById("resultat");
    if (!resultatElement) {
        console.error("Élément 'resultat' non trouvé dans le DOM.");
        return;
    }

    try {
        const response = await fetch("https://opendata-reunion.edf.fr/data-fair/api/v1/datasets/meteo-reseau-reunion/lines?limit=20");
        if (!response.ok) {
            throw new Error(`Erreur HTTP : ${response.status} - ${response.statusText}`);
        }
        const data = await response.json();
        console.log("Données brutes :", data);

        resultatElement.innerHTML = formatSelectedData(data);

    } catch (error) {
        console.error("Erreur :", error);
        resultatElement.innerHTML = `<p style="color: red;">Erreur : ${error.message}</p>`;
    }
}

// Appel de la fonction
recupMétéoElectrique();
